```
configure --disable-all --enable-cli --enable-zlib --enable-hash --enable-session --without-gd --with-bz2 --enable-memcache=shared
```
 - Build type       : Release
 - Thread Safety    : Yes
 - Compiler         : MSVC14 (Visual C++ 2015)
 - Architecture     : x64
 - Optimization     : PGO disabled
 - Static analyzer  : disabled